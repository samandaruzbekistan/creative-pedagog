<?php $__env->startSection('section'); ?>
    <div class="main-banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="header-text">
                        <h1 class="text-white"><?php echo e($block->name); ?></h1><br>
                        <h4 class="text-white">Vaqt: <span class="text-white" id="timer"></span></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <form action="<?php echo e(route('user.test.check')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="quiz_count" value="<?php echo e($block->quiz_count); ?>">
        <div class="container">
            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=> $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="small_tests">
                    <section class="small_test">
                        <div>
                            <h2 class="test_title"><?php echo e($id+1); ?>. </b> <?php echo e($quiz->quiz); ?></h2>
                            <?php $__currentLoopData = $quiz->answers->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label>
                                    <input type="radio" name="answer<?php echo e($id+1); ?>" value="<?php echo e($item->is_correct); ?>">
                                    <span><?php echo e($item->answer); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="container d-flex justify-content-center">
            <button type="submit" id="submit" class="btn text-white rounded "
                    style="font-size: 20px;background-color: #7a6ad8 !important;">Tekshirish
            </button>
        </div>
    </form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        function formatTime(seconds) {
            var h = Math.floor(seconds / 3600),
                m = Math.floor(seconds / 60) % 60,
                s = seconds % 60;
            if (h < 10) h = "0" + h;
            if (m < 10) m = "0" + m;
            if (s < 10) s = "0" + s;
            return h + ":" + m + ":" + s;
        }



        var count = <?php echo e($block->time*60); ?>;
        var counter = setInterval(timer, 1000);

        function timer() {
            count--;
            if (count < 0) {
                document.getElementById('submit').click();
            }
            document.getElementById('timer').innerHTML = formatTime(count);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\creative-pedagog\resources\views/user/test.blade.php ENDPATH**/ ?>