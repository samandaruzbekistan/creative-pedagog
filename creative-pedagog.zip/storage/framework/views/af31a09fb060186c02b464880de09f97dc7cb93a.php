<?php $__env->startSection('topic'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>

    <main class="content">
        <div class="container-fluid p-0">
            <div class="">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Taxririlash</h5>
                    </div>
                    <div class="card-body h-100">
                        <form action="<?php echo e(route('admin.topic.update')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label">Mavzu <span class="text-danger">*</span></label>
                                <input name="title" required type="text" class="form-control" value="<?php echo e($topic->title); ?>" placeholder="">
                            </div>
                            <input type="hidden" name="id" value="<?php echo e($topic->id); ?>">
                            <div class="mb-3">
                                <label class="form-label">Maqola</label>
                                <textarea name="editor" id="editor" cols="30" rows="10"><?php echo e($topic->body); ?></textarea>
                            </div>
                            <div class=" text-end">
                                <button type="submit" class="btn btn-success">Yangilash</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(".add").on("click", function () {
            $('.forma').show();
            $('.teachers').hide();
        });

        $(".cancel").on("click", function () {
            event.stopPropagation();
            $('.forma').hide();
            $('.teachers').show();
        });

        <?php if($errors->any()): ?>
        const notyf = new Notyf();

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        notyf.error({
            message: '<?php echo e($error); ?>',
            duration: 5000,
            dismissible: true,
            position: {
                x: 'center',
                y: 'top'
            },
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

        <?php if(session('success') == 1): ?>
        const notyf = new Notyf();

        notyf.success({
            message: 'Maqola yuklandi!',
            duration: 10000,
            dismissible: true,
            position: {
                x: 'right',
                y: 'bottom'
            },
        });
        <?php endif; ?>

        <?php if(session('update') == 1): ?>
        const notyf = new Notyf();

        notyf.warning({
            message: 'Maqola yangilandi!',
            duration: 10000,
            dismissible: true,
            position: {
                x: 'right',
                y: 'bottom'
            },
        });
        <?php endif; ?>
    </script>

    <script src="https://cdn.ckeditor.com/4.18.0/full/ckeditor.js"></script>

    <script>
        CKEDITOR.replace('editor', {
            filebrowserUploadUrl: "<?php echo e(route('imgUpload', ['_token'=> csrf_token()])); ?>",
            filebrowserUploadMethod: "form"
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\creative-pedagog\resources\views/admin/edit_topic.blade.php ENDPATH**/ ?>