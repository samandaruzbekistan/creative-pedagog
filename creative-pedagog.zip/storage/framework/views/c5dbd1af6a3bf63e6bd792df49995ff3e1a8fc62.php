<?php $__env->startSection('home'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">SMS xabarnoma xizmati</h5>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\creative-pedagog\resources\views/admin/home.blade.php ENDPATH**/ ?>