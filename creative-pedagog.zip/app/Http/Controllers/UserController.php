<?php

namespace App\Http\Controllers;

use App\Repositories\BlockRepository;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function __construct(protected BlockRepository $blockRepository)
    {
    }

    public function home(){
        $blocks = $this->blockRepository->getAll();
        return $blocks;
        return view('user.temp', ['blocks' => $blocks]);
    }
}
