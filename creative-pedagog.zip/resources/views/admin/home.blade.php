@extends('admin.header_footer')

@section('home')
    active
@endsection

@section('section')
    <main class="content">
        <div class="container-fluid p-0">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">SMS xabarnoma xizmati</h5>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection


